package com.example.design2javafx.HorrorCharacters;

public interface Transformable
{
    public void transform();
}
